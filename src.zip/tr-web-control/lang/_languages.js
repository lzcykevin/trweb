﻿// 设置当前可用的语言
system.languages = {
	"zh-CN":"简体中文|Chinese(Simplified)"
	,"en":"English"
};